#!/sbin/sh
#####################
SKIPUNZIP=1

unzip -j -o "${ZIPFILE}" 'Serialno/*' -d $MODPATH/Serialno >&2
unzip -j -o "${ZIPFILE}" 'service.sh' -d $MODPATH >&2
unzip -j -o "${ZIPFILE}" 'action.sh' -d $MODPATH >&2
unzip -j -o "${ZIPFILE}" 'uninstall.sh' -d $MODPATH >&2
unzip -j -o "${ZIPFILE}" 'module.prop' -d $MODPATH >&2

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0777
set_perm $MODPATH/action.sh 0 0 0777
set_perm $MODPATH/uninstall.sh 0 0 0755
set_perm $MODPATH/Serialno/Serialno.sh 0 0 0777

Serialno=$(tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 15)
while echo "$Serialno" | grep -q "'"
do
    echo ""
    echo "- - - - - - - - - -"
    echo "电报频道：@Whitelist520，阿灵出品，必属精品"
    echo "- - - - - - - - - -"
    echo ""
done 

echo "$Serialno
#你为什么要来看这里？
#如果你是小偷，偷东西死全家🤗" >$MODPATH/Serialno/TG频道@Whitelist520
am start -a android.intent.action.VIEW -d tg://resolve?domain=ALING521 >/dev/null 2>&1