#!/bin/sh

echo ""
echo -e "                  TG频道：@Whitelist520"
sleep 1s
echo -ne '                     □□□□□□□□□□0% '
sleep 0.1
echo -ne '                     ■■■■■■■■■■100% '
sleep 0.1

    echo ""
    echo "😔红线划过深藏轮回的秘密"
    echo "😭我挥霍运气"
    echo "💔因为你才让我背对命运不害怕"
    
    sleep 1

    
    
Serialno=$(tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 15)
while echo "$Serialno" | grep -q "'"
do
    echo ""
    echo "- - - - - - - - - -"
    echo "电报频道：@Whitelist520，阿灵出品，必属精品"
    echo "- - - - - - - - - -"
    echo ""
done 

echo "$Serialno
#你为什么要来看这里？
#如果你是小偷，偷东西死全家🤗" >/data/adb/modules/ALING_Serialno/Serialno/TG频道@Whitelist520
chmod 777 /data/adb/modules/ALING_Serialno/Serialno/Serialno.sh
sleep 1
/data/adb/modules/ALING_Serialno/Serialno/Serialno.sh


am start -a android.intent.action.VIEW -d tg://resolve?domain=Whitelist520 >/dev/null 2>&1